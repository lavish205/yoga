$(document).ready(function(){
		$('.step1').hide();
		$('.advantage1').hide();
		$('.caution1').hide();

		$('.step').click(function(){
			
			$('.step1').toggle();
		});
		$('.advantage').click(function(){
			$('.advantage1').toggle();
		});
		$('.caution').click(function(){
			$('.caution1').toggle();
		});
		$('#getstarted').click(function(){
			$(this).addClass('animated fadeOutLeft');
			$('#index_article').addClass('animated fadeOutLeft');
			$('#index_img').addClass('animated fadeOutLeft');
		});
		$('.glyphicon-chevron-down').addClass('pull-right');
});